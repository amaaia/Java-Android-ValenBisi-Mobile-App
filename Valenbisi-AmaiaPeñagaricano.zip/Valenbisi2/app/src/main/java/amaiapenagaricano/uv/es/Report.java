package amaiapenagaricano.uv.es;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;

@SuppressLint("ParcelCreator")
public class Report implements Parcelable {
    public int id;
    public String name;
    public String description;
    public int bikeStation;
    public String status;
    public String type;
    public byte[] image;

    public Report() {

    }
    protected Report(Parcel in) {
        name = in.readString();
        description = in.readString();
        bikeStation = in.readInt();
        status = in.readString();
        type = in.readString();
        id = in.readInt();
        image = in.createByteArray();
    }

    public static final Creator<Report> CREATOR = new Creator<Report>() {
        @Override
        public Report createFromParcel(Parcel in) {
            return new Report(in);
        }

        @Override
        public Report[] newArray(int size) {
            return new Report[size];
        }
    };

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getBikeStation() {
        return bikeStation;
    }

    public void setBikeStation(int bikeStation) {
        this.bikeStation = bikeStation;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(description);
        dest.writeInt(bikeStation);
        dest.writeString(status);
        dest.writeString(type);
        dest.writeInt(id);
        dest.writeByteArray(image);
    }
}
