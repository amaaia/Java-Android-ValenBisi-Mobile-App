package amaiapenagaricano.uv.es;

import android.content.Intent;
import android.database.Cursor;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DecimalFormat;

import uk.me.jstott.jcoord.UTMRef;

public class DetalleParada extends AppCompatActivity {

    TextView number;
    TextView address;
    TextView available;
    TextView coordinates;
    TextView distance;
    TextView free;
    TextView total;
    Parada parada;
    ReportsDBHelper db;
    AdapterReports partesAdapter;
    ListView lv;


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Bundle extras = getIntent().getExtras();
         parada =  extras.getParcelable("Parada");
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.newReport:
        // Do something when the user clicks on the new game
                Intent intent = new Intent(getApplicationContext(), ReportActivity.class);
                Report report = new Report();
                intent.putExtra("report",report);
                int number = parada.number;
                intent.putExtra("number", number);
                startActivity(intent);

                return true;
            case R.id.map:
                Uri gmmIntentUri;
                UTMRef utm = new UTMRef(parada.coordinate1, parada.coordinate2, 'N', 30);
                Location ParadaPoint = new Location("locationA");
                ParadaPoint.setLatitude(utm.toLatLng().getLat());
                ParadaPoint.setLongitude(utm.toLatLng().getLng());

                gmmIntentUri = Uri.parse("geo:0,0?q="+ParadaPoint.getLatitude()+","+ParadaPoint.getLongitude()+"("+parada.address+")");
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                mapIntent.setPackage("com.google.android.apps.maps");
                //If is installed in the application, the Google Maps activity is launched
                if (mapIntent.resolveActivity(getPackageManager()) != null) {
                    startActivity(mapIntent);
                }
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_parada);

        Bundle extras = getIntent().getExtras();
        Parada parada =  extras.getParcelable("Parada");

        this.number = this.findViewById(R.id.number);
        this.address = this.findViewById(R.id.address);
        this.total = this.findViewById(R.id.total);
        this.free = this.findViewById(R.id.free);
        this.available = this.findViewById(R.id.available);
        this.coordinates = this.findViewById(R.id.coordinates);
        this.distance = this.findViewById(R.id.distance);

        db = new ReportsDBHelper(getApplicationContext());
        Cursor partesByParada = db.findReportByBikeStation(parada.number);

        number.setText(Integer.toString(parada.number));
        address.setText(parada.address);
        total.setText(Integer.toString(parada.total));
        free.setText(Integer.toString(parada.free));
        available.setText(parada.available);

        DecimalFormat df = new DecimalFormat("#.##");
        coordinates.setText(df.format(parada.coordinate1)+ ", " + df.format(parada.coordinate2));

        distance.setText(df.format((parada.distance))+"m");

        this.setTitle(parada.address);

        partesAdapter = new AdapterReports(getApplicationContext(), partesByParada);
        lv=(ListView) findViewById(R.id.titleReport);
        lv.setAdapter(partesAdapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {

            Cursor cursor =(Cursor) parent.getItemAtPosition(position);
            Intent intent = new Intent(getApplicationContext(), ReportActivity.class);
            Report report = new Report();
            report.setId(Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow("_id"))));
            report.setBikeStation(Integer.parseInt(cursor.getString(cursor.getColumnIndexOrThrow("bikestation"))));
            report.setName(cursor.getString(cursor.getColumnIndexOrThrow("name")));
            report.setDescription(cursor.getString(cursor.getColumnIndexOrThrow("description")));
            report.setStatus(cursor.getString(cursor.getColumnIndexOrThrow("status")));
            report.setType(cursor.getString(cursor.getColumnIndexOrThrow("type")));
            report.setImage(cursor.getBlob(cursor.getColumnIndexOrThrow("image")));

            intent.putExtra("report",report);
            startActivity(intent);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        partesAdapter.swapCursor(db.findReportByBikeStation(parada.getNumber()));
        lv.setAdapter(partesAdapter);

    }
}
