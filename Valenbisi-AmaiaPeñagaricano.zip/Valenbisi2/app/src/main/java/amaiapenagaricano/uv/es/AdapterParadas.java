package amaiapenagaricano.uv.es;

import android.app.Service;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridLayout;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class AdapterParadas extends BaseAdapter {
    ArrayList<Parada> paradas;
    Context context;
    double coordinate1, coordinate2, distance;

    static class ViewHolder{
        TextView number;
        TextView address;
        TextView freeBikes;
        TextView distance;

    }

    public void updateData(ArrayList<Parada> paradas) {
        this.paradas = paradas;
    }

    public AdapterParadas(Context c, int listparadaview) {
        context = c;
        paradas = new ArrayList<Parada>();
    }

    @Override
    public int getCount() {
        return paradas.size();
    }

    @Override
    public Object getItem(int position) {
        return paradas.get(position);
    }

    @Override
    public long getItemId(int position) {
        return paradas.get(position).number;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        ViewHolder holder = null;
        if (view == null){
            LayoutInflater li = (LayoutInflater)context.getSystemService(Service.LAYOUT_INFLATER_SERVICE);
            view = li.inflate (R.layout.listparadaview ,null);
            holder = new ViewHolder( );
            holder.number = (TextView) view.findViewById(R.id.paradaviewnumber);
            holder.address = (TextView) view.findViewById(R.id.paradaviewaddress);
            holder.freeBikes = (TextView) view.findViewById(R.id.paradaviewfreebikes);
            holder.distance = (TextView) view.findViewById(R.id.paradaviewdistance);

            view.setTag ( holder ) ;

        } else {
            holder = (ViewHolder) view.getTag( );

        }
        GridLayout baseLayout = view.findViewById(R.id.baseLayout);
        Parada p = (Parada) this.getItem(position);
        holder.number.setText(Integer.toString(p.number));
        holder.address.setText(p.address);
        holder.freeBikes.setText(Integer.toString(p.free));

        DecimalFormat df = new DecimalFormat("#.##");
        holder.distance.setText(df.format(p.distance)+"m");

        if(p.free < 5){
            baseLayout.setBackgroundColor(Color.rgb(213,78,33));
        } else if(p.free < 10){
            baseLayout.setBackgroundColor(Color.rgb(255,202,10));
        } else {
            baseLayout.setBackgroundColor(Color.rgb(87, 179, 73));
        }

        return view;
    }
}
