package amaiapenagaricano.uv.es;

import android.location.Location;
import android.os.AsyncTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import uk.me.jstott.jcoord.UTMRef;

class HTTPConnector extends AsyncTask<String, Void, ArrayList> {

    ArrayList<Parada> paradas;
    Writer writer = new StringWriter();
    HttpURLConnection con;
    URL obj;
    AdapterParadas adapterParadas;

    HTTPConnector(AdapterParadas adapterParadas){
        this.adapterParadas = adapterParadas;
    }

    @Override
    protected ArrayList doInBackground(String... params) {
        paradas = new ArrayList<Parada>();

        String url = "https://drive.google.com/uc?export=download&id=10bsaBPZ-5QoAF9ludW0Lxt8svrHFyMH6";

        char[] buffer = new char[1024];
        try {
            obj = new URL(url);
            con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("GET");
            //add request header
            con.setRequestProperty("user-Agent", "Mozilla/5.0 (Windows NT 10.0; WOW64),AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36");
            con.setRequestProperty("accept", "application/json;");
            con.setRequestProperty("accept-language", "es");
            con.connect();
            int responseCode = con.getResponseCode();
            if (responseCode != HttpURLConnection.HTTP_OK) {
                throw new IOException("HTTP error code: " + responseCode);
            }
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream(),
                    "UTF-8"));
            int n;
            while ((n = in.read(buffer)) != -1) {
                writer.write(buffer, 0, n);
            }
            in.close();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            JSONObject jsonObject = new JSONObject(writer.toString());
            JSONArray jsonArray = jsonObject.getJSONArray("features");
            for(int i = 0; i < jsonArray.length(); i++){

                JSONObject properties = jsonArray.getJSONObject(i).getJSONObject("properties");
                JSONObject geometry = jsonArray.getJSONObject(i).getJSONObject("geometry");

                Parada parada = new Parada();

                parada.name = properties.getString("name");
                parada.number = properties.getInt("number");
                parada.address = properties.getString("address");
                parada.open = properties.getString("open");
                parada.available = properties.getString("available");
                parada.free = properties.getInt("free");
                parada.total = properties.getInt("total");
                parada.ticket = properties.getString("ticket");
                parada.coordinates = geometry.getJSONArray("coordinates");
                parada.coordinate1 = parada.coordinates.getDouble(0);
                parada.coordinate2 = parada.coordinates.getDouble(1);
                parada.setCoordinate1(parada.coordinate1);
                parada.setCoordinate2(parada.coordinate2);

                UTMRef utm = new UTMRef(parada.coordinate1, parada.coordinate2, 'N', 30);
                Location ParadaPoint = new Location("locationA");
                ParadaPoint.setLatitude(utm.toLatLng().getLat());
                ParadaPoint.setLongitude(utm.toLatLng().getLng());

                Location ETSEPoint=new Location("locationETSE");
                ETSEPoint.setLatitude(39.512634);
                ETSEPoint.setLongitude(-0.424035);

                parada.distance = ParadaPoint.distanceTo(ETSEPoint);

                paradas.add(parada);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return paradas;
    }

    @Override
    protected void onPostExecute(ArrayList paradas) {
        adapterParadas.updateData(this.paradas);
        adapterParadas.notifyDataSetChanged();
    }
}