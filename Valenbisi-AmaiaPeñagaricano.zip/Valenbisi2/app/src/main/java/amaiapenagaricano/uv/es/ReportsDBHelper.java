package amaiapenagaricano.uv.es;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import static amaiapenagaricano.uv.es.ReportContract.ReportEntry.COLUMN_NAME_BIKESTATION;
import static amaiapenagaricano.uv.es.ReportContract.ReportEntry.TABLE_NAME;
import static amaiapenagaricano.uv.es.ReportContract.SQL_CREATE_ENTRIES;
import static amaiapenagaricano.uv.es.ReportContract.SQL_DELETE_ENTRIES;
import static android.provider.BaseColumns._ID;

public class ReportsDBHelper extends SQLiteOpenHelper {
    // If you change the database schema, you must increment the database version.
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "Reports.db";

    public ReportsDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(SQL_CREATE_ENTRIES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }

    public void onDelete(SQLiteDatabase db) {
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }

    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }

    public void insertReport(int stationValue, String nameValue, String descriptionValue, String statusValue, String typeValue, byte[] imageValue) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues newValues = new ContentValues();
        newValues.put("bikestation ", stationValue);
        newValues.put("name ", nameValue);
        newValues.put("description ",descriptionValue);
        newValues.put("status ",statusValue);
        newValues.put("type ",typeValue);
        newValues.put("image ",imageValue);


        db.insert(TABLE_NAME,null,newValues);
    }

    public void updateReport( int ID, String nameValue, String descriptionValue, String statusValue, String typeValue, byte[] imageValue) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues newValues = new ContentValues();
        newValues.put("name",nameValue);
        newValues.put("description",descriptionValue);
        newValues.put("status",statusValue);
        newValues.put("type",typeValue);
        newValues.put("image",imageValue);
        String[] selectionArgs = {Integer.toString(ID)};

        db.update(TABLE_NAME, newValues, _ID  + " = ?", selectionArgs);
    }

    public void deleteReport(int ID) {
        SQLiteDatabase db = this.getWritableDatabase();
        String[] selectionArgs = {Integer.toString(ID)};

        db.delete(TABLE_NAME, _ID + " LIKE ?", selectionArgs);
    }

    public Cursor findReportByBikeStation(int bikeStationValue) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] column = {"*"};
        String[] selectionArgs = {Integer.toString(bikeStationValue)};

        return db.query(TABLE_NAME, column, COLUMN_NAME_BIKESTATION + " LIKE ?" , selectionArgs, null, null, _ID);
    }

    public Cursor findReportByID(int reportIDValue) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] column = {"*"};
        String[] selectionArgs = {Integer.toString(reportIDValue)};

        return db.query(TABLE_NAME, column, _ID + " LIKE ?", selectionArgs, null, null, _ID);
    }
}