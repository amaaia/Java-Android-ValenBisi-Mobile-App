package amaiapenagaricano.uv.es;

import android.provider.BaseColumns;

public class ReportContract {
    // To prevent someone from accidentally instantiating the contract class,
    // make the constructor private.
    private ReportContract() {}

    /* Inner class that defines the table contents */
    public static class ReportEntry implements BaseColumns {
        public static final String TABLE_NAME = "TReports";
        public static final String COLUMN_NAME_BIKESTATION = "bikestation";
        public static final String COLUMN_NAME_NAME = "name";
        public static final String COLUMN_NAME_DESCRIPTION = "description";
        public static final String COLUMN_NAME_STATUS = "status";
        public static final String COLUMN_NAME_TYPE = "type";
        public static final String COLUMN_NAME_IMAGE = "image";
    }

    public static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + ReportEntry.TABLE_NAME + " (" +
                    ReportEntry._ID + " INTEGER PRIMARY KEY autoincrement," +
                    ReportEntry.COLUMN_NAME_BIKESTATION + " TEXT," +
                    ReportEntry.COLUMN_NAME_NAME + " TEXT," +
                    ReportEntry.COLUMN_NAME_DESCRIPTION + " TEXT," +
                    ReportEntry.COLUMN_NAME_STATUS + " TEXT," +
                    ReportEntry.COLUMN_NAME_TYPE + " TEXT," +
                    ReportEntry.COLUMN_NAME_IMAGE + " BLOB)";

    public static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + ReportEntry.TABLE_NAME;
}
