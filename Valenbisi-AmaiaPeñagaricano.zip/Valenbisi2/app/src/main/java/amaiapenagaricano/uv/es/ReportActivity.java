package amaiapenagaricano.uv.es;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import java.io.ByteArrayOutputStream;

public class ReportActivity extends AppCompatActivity {

    static final int REQUEST_IMAGE_CAPTURE = 1;
    Report report;
    ReportsDBHelper db;
    Spinner statusSpinner, typeSpinner;
    EditText title, description;
    int number;
    Bitmap bitmap;
    ImageView imageView;

  protected void onCreate(Bundle savedInstanceState) {

      super.onCreate(savedInstanceState);

      setContentView(R.layout.activity_detalle_report);
      db = new ReportsDBHelper(getApplicationContext());

      statusSpinner = (Spinner) findViewById((R.id.status_spinner));
      ArrayAdapter<CharSequence> adapterStatus = ArrayAdapter.createFromResource(this,R.array.status_array,android.R.layout.simple_spinner_dropdown_item);
      adapterStatus.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
      statusSpinner.setAdapter(adapterStatus);

      typeSpinner = (Spinner) findViewById(R.id.type_spinner);
      ArrayAdapter<CharSequence> adapterType = ArrayAdapter.createFromResource(this, R.array.type_array, android.R.layout.simple_spinner_dropdown_item);
      adapterType.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
      typeSpinner.setAdapter(adapterType);

      Intent intent = getIntent();
      report = intent.getExtras().getParcelable("report");

      title = (EditText) findViewById(R.id.title);
      description = (EditText) findViewById(R.id.description);

      imageView = findViewById(R.id.camera);

      if(report.getId() != 0) {
          setTitle("Edit report");

          title.setText(report.getName());

          description.setText(report.getDescription());

          int statusIndex = adapterStatus.getPosition(report.getStatus());
          statusSpinner.setSelection(statusIndex);

          int typeIndex = adapterType.getPosition(report.getType());
          typeSpinner.setSelection(typeIndex);

          if(report.getImage() != null)
            imageView.setImageBitmap(getImage(report.getImage()));

      } else
          setTitle("New report");
  }
  public static Bitmap getImage(byte[] image) {
        return BitmapFactory.decodeByteArray(image, 0, image.length);
    }

    public static byte[] getBytes(Bitmap bitmap) {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 0, stream);
        return stream.toByteArray();
    }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
      MenuInflater inflater = getMenuInflater();
      inflater.inflate(R.menu.report_menu, menu);
      return true;
  }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()) {
            case R.id.saveReport:
                saveReport();
                return true;

            case R.id.deleteReport:
                deleteReport();
                return true;

            case R.id.addPhoto:
                takePhoto();
                return true;

            default:
                return super.onOptionsItemSelected(item);

        }

    }

    private void saveReport() {
        Report newReport = new Report();
        newReport.setName(title.getText().toString());
        newReport.setDescription(description.getText().toString());
        newReport.setStatus(statusSpinner.getSelectedItem().toString());
        newReport.setType(typeSpinner.getSelectedItem().toString());
        newReport.setBikeStation(report.getBikeStation());

        if(bitmap != null ) {
            newReport.setImage(getBytes(bitmap));
        }
        if (report.getId() == 0) {
            number = getIntent().getExtras().getInt("number");
            db.insertReport(number, newReport.getName(), newReport.getDescription(), newReport.getStatus(), newReport.getType(), newReport.getImage());

            onBackPressed();
        } else {
            db.updateReport(report.getId(), newReport.getName(), newReport.getDescription(), newReport.getStatus(), newReport.getType(), newReport.getImage());
        }

        Intent intent = new Intent(getApplicationContext(), ListaParadas.class);
        startActivity(intent);
        finish();
    }

    private void takePhoto() {
      Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

      if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
          startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
      }
    }

    private void deleteReport() {
        db.deleteReport(report.getId());

        Intent intent = new Intent(getApplicationContext(), ListaParadas.class);
        startActivity(intent);
        finish();
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            bitmap = (Bitmap) extras.get("data");
            imageView.setImageBitmap(bitmap);
        }
    }
}
