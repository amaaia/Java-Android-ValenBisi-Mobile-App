package amaiapenagaricano.uv.es;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;

import org.json.JSONArray;

import java.util.Date;

@SuppressLint("ParcelCreator")
public class Parada implements Parcelable {

    public String name;
    public int number;
    public String address;
    public String open;
    public String available;
    public int free;
    public int total;
    public String ticket;
    public Date updated_at;
    public JSONArray coordinates;
    public double distance;
    public double coordinate1;
    public double coordinate2;


    protected Parada(Parcel in) {

        name = in.readString();
        number = in.readInt();
        address = in.readString();
        open = in.readString();
        available = in.readString();
        free = in.readInt();
        total = in.readInt();
        ticket = in.readString();
        distance = in.readDouble();
        coordinate1 = in.readDouble();
        coordinate2 = in.readDouble();
    }

    public static final Creator<Parada> CREATOR = new Creator<Parada>() {
        @Override
        public Parada createFromParcel(Parcel in) {
            return new Parada(in);
        }

        @Override
        public Parada[] newArray(int size) {
            return new Parada[size];
        }
    };

    public Parada() {

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getOpen() {
        return open;
    }

    public void setOpen(String open) {
        this.open = open;
    }

    public String getAvailable() {
        return available;
    }

    public void setAvailable(String available) {
        this.available = available;
    }

    public int getFree() {
        return free;
    }

    public void setFree(int free) {
        this.free = free;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public Date getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(Date updated_at) {
        this.updated_at = updated_at;
    }

    public void setCoordinate1(double coordinate1) {
        this.coordinate1 = coordinate1;
    }

    public void setCoordinate2(double coordinate2) {
        this.coordinate2 = coordinate2;
    }

    public JSONArray getCoordinates() {
        return coordinates;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeInt(number);
        dest.writeString(address);
        dest.writeString(open);
        dest.writeString(available);
        dest.writeInt(free);
        dest.writeInt(total);
        dest.writeString(ticket);
        dest.writeDouble(distance);
        dest.writeDouble(coordinate1);
        dest.writeDouble(coordinate2);

    }

}
