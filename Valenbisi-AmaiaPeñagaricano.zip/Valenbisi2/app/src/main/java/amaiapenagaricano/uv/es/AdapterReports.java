package amaiapenagaricano.uv.es;

import android.app.Service;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.TextView;

public class AdapterReports extends CursorAdapter {


    public AdapterReports(Context context, Cursor c) {
        super(context,c, 0);
    }

    static class ViewHolder{
        TextView name;
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        LayoutInflater li = (LayoutInflater)context.getSystemService(Service.LAYOUT_INFLATER_SERVICE);
        View view = li.inflate(R.layout.listreportsview, null);
        fillView(view, cursor);
        return view;
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        fillView(view, cursor);
    }

    private void fillView(View view, Cursor cursor) {
        // Get information from the cursor
        String name = cursor.getString(cursor.getColumnIndex(ReportContract.ReportEntry.COLUMN_NAME_NAME));
        String status = cursor.getString(cursor.getColumnIndex(ReportContract.ReportEntry.COLUMN_NAME_STATUS));

        // Try to obtain the ViewHolder from the view
        ViewHolder holder = (ViewHolder) view.getTag();

        TextView tvName;

        if(holder != null) {
            tvName = holder.name;
        }
        else {
            tvName =(TextView) view.findViewById(R.id.reportName);
            view.setTag(holder);
        }

        tvName.setText(name);
        TextView statusColor = view.findViewById(R.id.reportStatus);

        if (status.equals("Open")) {
            statusColor.setBackgroundColor(Color.rgb(0,255,0));
        }else if(status.equals("Processing")) {
            statusColor.setBackgroundColor(Color.rgb(255,255,0));
        }else {
            statusColor.setBackgroundColor(Color.rgb(255,0,0));
        }
    }
}
