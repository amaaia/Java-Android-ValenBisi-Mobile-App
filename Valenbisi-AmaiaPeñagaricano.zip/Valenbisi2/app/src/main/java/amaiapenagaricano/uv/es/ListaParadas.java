package amaiapenagaricano.uv.es;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

public class ListaParadas extends AppCompatActivity {
    HTTPConnector httpConnector;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_lista_paradas);
        ListView listView = (ListView) findViewById(R.id.list_view);

        final AdapterParadas adapter = new AdapterParadas(this, R.layout.listparadaview);
        listView.setAdapter(adapter);
        httpConnector = (HTTPConnector) new HTTPConnector(adapter).execute();


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            Parada parada = (Parada) parent.getItemAtPosition(position);

            Intent intent = new Intent(getApplicationContext(), DetalleParada.class);
            intent.putExtra("Parada",parada);
            startActivity(intent);
            }
        });
    }
}
